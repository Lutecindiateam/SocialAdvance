import { useEffect } from "react";
import Layout from "./Layout";
// import { useNavigate } from "react-router-dom";

const Account = () => {
    // const navigate = useNavigate()
    // useEffect(() => {
    //     // navigate("*")
    // },[])
    return (
        <Layout>
        <p> 🦍🦍🦍🦍  </p>
        </Layout>

    )
}
export default Account;