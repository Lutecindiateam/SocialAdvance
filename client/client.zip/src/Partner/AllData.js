import React from 'react'

/**
* @author
* @function AllData
**/

export const AllData = (props) => {
  return(
    <div>AllData</div>
   )

 }