// AddUser.js

import React from 'react';

const AddUser = () => {
  return <div>Add User Page</div>;
};

export default AddUser;
