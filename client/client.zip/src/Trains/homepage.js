import React from 'react'

/**
* @author
* @function Information
**/

const Information = (props) => {
  return(
    <div>Information</div>
   )

 }
 export default Information