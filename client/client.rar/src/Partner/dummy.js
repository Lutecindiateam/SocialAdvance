function Dummy() {
    return [
      
      {
        "id": 1,
        "businessname": "ABC Inc.",
        "mobilenumber": "123-456-7890",
        "address": "123 Main St",
        "pincode": "12345",
        "city": "City1",
        "state": "State1",
        "category": "Category1",
        "subcategory": "Subcategory1"
      },
      {
        "id": 2,
        "businessname": "XYZ Corp.",
        "mobilenumber": "987-654-3210",
        "address": "456 Oak St",
        "pincode": "67890",
        "city": "City2",
        "state": "State2",
        "category": "Category2",
        "subcategory": "Subcategory2"
      },
      {
        "id": 3,
        "businessname": "LMN Enterprises",
        "mobilenumber": "555-123-4567",
        "address": "789 Elm St",
        "pincode": "54321",
        "city": "City3",
        "state": "State3",
        "category": "Category3",
        "subcategory": "Subcategory3"
      },
      {
        "id": 4,
        "businessname": "PQR Innovations",
        "mobilenumber": "999-888-7777",
        "address": "567 Birch St",
        "pincode": "98765",
        "city": "City4",
        "state": "State4",
        "category": "Category4",
        "subcategory": "Subcategory4"
      },
      {
        "id": 5,
        "businessname": "UVW Solutions",
        "mobilenumber": "444-555-6666",
        "address": "321 Maple St",
        "pincode": "13579",
        "city": "City5",
        "state": "State5",
        "category": "Category5",
        "subcategory": "Subcategory5"
      }
    
      
          
    ];
  }
  
  module.exports = Dummy;